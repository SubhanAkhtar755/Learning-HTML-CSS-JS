setTimeout(()=>{
window.location.href = './web.html'
},3000)